package com.dailybloom.tracker

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val title = intent?.getStringExtra("title") ?: "Daily Bloom reminder"
        val time = intent?.getStringExtra("time") ?: "8:00 AM"
        val id = intent?.getStringExtra("id") ?: "default"
        createChannel(context)
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Daily Bloom")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        try { NotificationManagerCompat.from(context).notify(id.hashCode(), notification) } catch (_: SecurityException) { }
        scheduleOne(context, id, title, time, true)
    }

    companion object {
        private const val CHANNEL = "daily_bloom_reminders"
        fun createChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val channel = NotificationChannel(CHANNEL, "Daily Bloom reminders", NotificationManager.IMPORTANCE_HIGH)
                channel.description = "Daily activity and water reminders"
                (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
            }
        }
        fun cancel(context: Context, id: String) {
            val intent = Intent(context, ReminderReceiver::class.java)
            val pi = PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi); pi.cancel() }
        }
        fun scheduleOne(context: Context, id: String, title: String, time: String, tomorrow: Boolean = false) {
            val parts = time.trim().uppercase().split(Regex("\\s+"))
            if (parts.size != 2) return
            val hm = parts[0].split(":")
            if (hm.size != 2) return
            var hour = hm[0].toIntOrNull() ?: return
            val minute = hm[1].toIntOrNull() ?: return
            if (hour !in 1..12 || minute !in 0..59) return
            if (parts[1] == "PM" && hour != 12) hour += 12
            if (parts[1] == "AM" && hour == 12) hour = 0
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (tomorrow || timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(context, ReminderReceiver::class.java).putExtra("id", id).putExtra("title", title).putExtra("time", time)
            val pi = PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } catch (_: SecurityException) { am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) }
        }
    }
}

object ReminderScheduler {
    fun scheduleAll(context: Context) {
        val prefs = context.getSharedPreferences("dailybloom", Context.MODE_PRIVATE)
        val raw = prefs.getString("tasks", null)
        val items = try {
            if (raw == null) null else org.json.JSONArray(raw).let { a -> (0 until a.length()).map { a.getJSONObject(it) } }
        } catch (_: Exception) { null }
        if (raw == null) {
            listOf(Triple("wake", "Wake up", "4:00 AM"), Triple("gratitude-am", "Morning gratitude", "4:05 AM"), Triple("coconut", "Eat coconut", "5:00 PM"), Triple("gratitude-pm", "Evening gratitude", "8:55 PM")).forEach { ReminderReceiver.scheduleOne(context, it.first, it.second, it.third) }
        } else items.orEmpty().forEach { obj ->
            ReminderReceiver.scheduleOne(context, obj.optString("id"), obj.optString("title"), obj.optString("time"))
        }
        val waterRaw = prefs.getString("water_slots", null)
        try {
            if (waterRaw != null) {
                val a = org.json.JSONArray(waterRaw)
                for (i in 0 until a.length()) {
                    val obj = a.getJSONObject(i)
                    ReminderReceiver.scheduleOne(context, "water_" + obj.optString("id"), "Drink water – " + obj.optInt("ml", 200) + " ml", obj.optString("time"))
                }
            }
        } catch (_: Exception) { }

    }
}
