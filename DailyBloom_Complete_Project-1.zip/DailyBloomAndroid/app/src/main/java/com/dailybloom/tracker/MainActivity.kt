package com.dailybloom.tracker

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import java.text.SimpleDateFormat
import java.util.*

private val Cream = Color(0xFFFFF9F2)
private val Pink = Color(0xFFF4E5E8)
private val Sage = Color(0xFF8D9F89)
private val Ink = Color(0xFF51454A)
private val dateFmt = SimpleDateFormat("yyyyMMdd", Locale.US)
private fun todayKey() = dateFmt.format(Date())
private fun newId() = UUID.randomUUID().toString()

data class BloomTask(val id:String, val title:String, val time:String, val category:String)
data class Supplement(val id:String, val name:String, val dose:String, val time:String)
data class BloomBook(val id:String, val title:String, val notes:String, val page:Int, val total:Int, val finished:Boolean)
data class WaterSlot(val id:String, val time:String, val ml:Int)

private fun defaultTasks() = listOf(
    BloomTask("wake","Wake up","4:00 AM","Morning"), BloomTask("gratitude-am","Morning gratitude","4:05 AM","Mindfulness"),
    BloomTask("study","Morning study","4:45 AM","Study"), BloomTask("walk","Walking / movement","6:00 AM","Fitness"),
    BloomTask("breakfast","Breakfast","8:30 AM","Health"), BloomTask("coconut","Eat coconut","5:00 PM","Health"),
    BloomTask("gratitude-pm","Evening gratitude","8:55 PM","Mindfulness")
)
private fun defaultWater() = (0 until 8).map { WaterSlot("w$it", listOf("6:30 AM","9:00 AM","10:30 AM","12:00 PM","2:00 PM","3:30 PM","5:00 PM","6:30 PM")[it],200) }

class MainActivity : ComponentActivity() {
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        ReminderReceiver.createChannel(this)
        ReminderScheduler.scheduleAll(this)
        setContent { DailyBloomApp() }
    }
}

@Composable private fun DailyBloomApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("dailybloom", Context.MODE_PRIVATE) }
    var tab by remember { mutableIntStateOf(0) }
    var tasks by remember { mutableStateOf(loadTasks(prefs)) }
    var supplements by remember { mutableStateOf(loadSupplements(prefs)) }
    var books by remember { mutableStateOf(loadBooks(prefs)) }
    var water by remember { mutableStateOf(loadWater(prefs)) }
    var waterTarget by remember { mutableIntStateOf(prefs.getInt("water_target",1600)) }
    var glassDefault by remember { mutableIntStateOf(prefs.getInt("water_glass",200)) }
    var selectedDate by remember { mutableStateOf(todayKey()) }
    var taskDialog by remember { mutableStateOf<BloomTask?>(null) }
    var supplementDialog by remember { mutableStateOf<Supplement?>(null) }
    var bookDialog by remember { mutableStateOf<BloomBook?>(null) }
    var showNewTask by remember { mutableStateOf(false) }
    var showNewSupplement by remember { mutableStateOf(false) }
    var showNewBook by remember { mutableStateOf(false) }
    var diaryProud by remember { mutableStateOf(prefs.getString("diary_${todayKey()}_proud","") ?: "") }
    var diaryLesson by remember { mutableStateOf(prefs.getString("diary_${todayKey()}_lesson","") ?: "") }
    var diaryFeelings by remember { mutableStateOf(prefs.getString("diary_${todayKey()}_feelings","") ?: "") }
    var diaryTomorrow by remember { mutableStateOf(prefs.getString("diary_${todayKey()}_tomorrow","") ?: "") }
    var diarySaved by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    val tts = remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) { val engine = TextToSpeech(ctx) { status -> if(status == TextToSpeech.SUCCESS) tts.value?.language = Locale("en","IN") }; tts.value=engine; onDispose { engine.stop(); engine.shutdown() } }
    fun saveTasks(v:List<BloomTask>) { tasks.filter { old -> v.none { it.id == old.id } }.forEach { ReminderReceiver.cancel(ctx, it.id) }; tasks=v; prefs.edit().putString("tasks", encodeTasks(v)).apply(); ReminderScheduler.scheduleAll(ctx) }
    fun saveSupps(v:List<Supplement>) { supplements=v; prefs.edit().putString("supplements",encodeSupps(v)).apply() }
    fun saveBooks(v:List<BloomBook>) { books=v; prefs.edit().putString("bloom_books_v2",encodeBooks(v)).apply() }
    fun saveWater(v:List<WaterSlot>) { water.filter { old -> v.none { it.id == old.id } }.forEach { ReminderReceiver.cancel(ctx, "water_" + it.id) }; water=v; prefs.edit().putString("water_slots",encodeWater(v)).apply(); ReminderScheduler.scheduleAll(ctx) }
    fun checked(key:String) = prefs.getBoolean(key,false)
    fun toggle(key:String, value:Boolean) { prefs.edit().putBoolean(key,value).apply(); refresh++ }
    val date = selectedDate
    val taskDone = tasks.count { checked("task_${date}_${it.id}") } + refresh * 0
    val waterDone = water.filter { checked("water_${date}_${it.id}") }.sumOf { it.ml } + refresh * 0
    val suppDone = supplements.count { checked("supp_${date}_${it.id}") } + refresh * 0
    MaterialTheme(colorScheme=lightColorScheme(primary=Color(0xFF9A7180), background=Cream, surface=Color.White, onSurface=Ink)) {
        Scaffold(containerColor=Cream, bottomBar={ NavigationBar(containerColor=Color.White) {
            val labels=listOf("Today","Water","Supplements","Books","Healing","Diary","Analytics")
            labels.forEachIndexed { i,s -> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(listOf("☀","💧","🌿","📚","♡","✎","✦")[i])},label={Text(s,fontSize=9.sp)}) }
        }}) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=16.dp)) {
                Spacer(Modifier.height(14.dp)); Text("DAILY BLOOM",color=Sage,fontSize=12.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
                Text(listOf("A gentle day, one step at a time","Water check-in","Your supplements","Your reading corner","Healing corner","Proud & regret moments diary","Your progress")[tab],fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink)
                Spacer(Modifier.height(10.dp))
                when(tab) {
                    0 -> LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=16.dp)) {
                        item { CardBox { Text("TODAY'S ROUTINE",color=Ink,fontWeight=FontWeight.Bold); Text("$taskDone / ${tasks.size} completed",fontSize=21.sp,fontWeight=FontWeight.Bold); LinearProgressIndicator(progress={if(tasks.isEmpty()) 0f else taskDone.toFloat()/tasks.size},modifier=Modifier.fillMaxWidth(),color=Sage); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(onClick={showNewTask=true}){Text("+ Add activity")}; OutlinedButton(onClick={selectedDate=todayKey()}){Text("Today")}} } }
                        items(tasks,key={it.id}) { task -> val done=checked("task_${date}_${task.id}"); RowCard { Checkbox(done,{toggle("task_${date}_${task.id}",it)}); Column(Modifier.weight(1f)){Text(task.title,fontWeight=FontWeight.SemiBold);Text("${task.time} • ${task.category}",fontSize=12.sp,color=Color.Gray)}; TextButton(onClick={taskDialog=task}){Text("Edit")}; TextButton(onClick={saveTasks(tasks.filterNot{it.id==task.id})}){Text("Delete",color=Color(0xFFAA5964))} } }
                    }
                    1 -> LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=16.dp)) {
                        item { CardBox { Text("Daily target",fontWeight=FontWeight.Bold); Text("$waterDone / $waterTarget ml",fontSize=22.sp); LinearProgressIndicator(progress={ (waterDone.toFloat()/waterTarget.coerceAtLeast(1)).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth(),color=Color(0xFF83B7C5)); Row { OutlinedButton(onClick={waterTarget=(waterTarget-100).coerceAtLeast(100);prefs.edit().putInt("water_target",waterTarget).apply()}){Text("− Target")}; OutlinedButton(onClick={waterTarget+=100;prefs.edit().putInt("water_target",waterTarget).apply()}){Text("+ Target")}; OutlinedButton(onClick={saveWater(water+WaterSlot(newId(),"7:00 PM",glassDefault))}){Text("+ Reminder")}} } }
                        items(water,key={it.id}) { slot -> RowCard { val done=checked("water_${date}_${slot.id}"); Checkbox(done,{toggle("water_${date}_${slot.id}",it)}); Column(Modifier.weight(1f)){Text(slot.time,fontWeight=FontWeight.SemiBold);Text("${slot.ml} ml",fontSize=12.sp,color=Color.Gray)}; TextButton(onClick={editWaterDialog(ctx,slot){updated->saveWater(water.map{if(it.id==slot.id)updated else it})}}){Text("Edit")}; TextButton(onClick={saveWater(water.filterNot{it.id==slot.id})}){Text("Delete")} } }
                        item { OutlinedButton(onClick={glassDefault=(glassDefault+50).coerceAtMost(1000);prefs.edit().putInt("water_glass",glassDefault).apply()}){Text("Default glass size: $glassDefault ml  (+50)")} }
                    }
                    2 -> LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=16.dp)) {
                        item { CardBox { Text("Supplements tracker",fontWeight=FontWeight.Bold); Text("$suppDone / ${supplements.size} taken today"); Button(onClick={showNewSupplement=true}){Text("+ Add supplement")} } }
                        items(supplements,key={it.id}) { s -> RowCard { val done=checked("supp_${date}_${s.id}"); Checkbox(done,{toggle("supp_${date}_${s.id}",it)}); Column(Modifier.weight(1f)){Text(s.name,fontWeight=FontWeight.SemiBold);Text("${s.dose} • ${s.time}",fontSize=12.sp,color=Color.Gray);Text(if(done)"Taken" else "Not taken",fontSize=11.sp,color=if(done)Sage else Color.Gray)}; TextButton(onClick={supplementDialog=s}){Text("Edit")}; TextButton(onClick={saveSupps(supplements.filterNot{it.id==s.id})}){Text("Delete",color=Color(0xFFAA5964))} } }
                        item { Text("No alarms for supplements. Your daily check-ins are saved by date.",fontSize=12.sp,color=Color.Gray) }
                    }
                    3 -> LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=16.dp)) {
                        item { CardBox { Text("Monthly goal: 2 books",fontWeight=FontWeight.Bold); Text("${books.count{it.finished}} completed • ${books.size} in your library"); Button(onClick={showNewBook=true}){Text("+ Add book")} } }
                        items(books,key={it.id}) { b -> RowCard { Column(Modifier.weight(1f)){Text(b.title,fontWeight=FontWeight.Bold);Text("${b.page} / ${b.total} pages",fontSize=12.sp,color=Color.Gray);Text(if(b.finished)"Completed" else b.notes.ifBlank{"No notes yet"},fontSize=12.sp,maxLines=2,color=Ink)}; TextButton(onClick={bookDialog=b}){Text("Edit / Notes")}; TextButton(onClick={saveBooks(books.filterNot{it.id==b.id})}){Text("Delete")} } }
                    }
                    4 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("Take a slow breath. Listen gently and repeat as you like.",color=Color.Gray)
                        listOf("I am sorry","Please forgive me","Thank you","I love you","I forgive myself").forEach { phrase -> Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Pink)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(phrase,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);TextButton(onClick={tts.value?.speak(phrase,TextToSpeech.QUEUE_FLUSH,null,"affirmation")}){Text("▶ Play")}}} }
                        Row { OutlinedButton(onClick={tts.value?.stop()}){Text("Pause / Stop")}; Button(onClick={tts.value?.speak("I am sorry. Please forgive me. Thank you. I love you. I forgive myself.",TextToSpeech.QUEUE_FLUSH,null,"all")}){Text("Play all") } }
                    }
                    5 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("Today's entry • ${todayKey()}",color=Sage,fontWeight=FontWeight.Bold)
                        OutlinedTextField(diaryProud,{diaryProud=it;diarySaved=false},label={Text("Proud moments")},modifier=Modifier.fillMaxWidth(),minLines=2)
                        OutlinedTextField(diaryLesson,{diaryLesson=it;diarySaved=false},label={Text("Regrets / lessons")},modifier=Modifier.fillMaxWidth(),minLines=2)
                        OutlinedTextField(diaryFeelings,{diaryFeelings=it;diarySaved=false},label={Text("Free writing – how I feel")},modifier=Modifier.fillMaxWidth(),minLines=3)
                        OutlinedTextField(diaryTomorrow,{diaryTomorrow=it;diarySaved=false},label={Text("Tomorrow's intention")},modifier=Modifier.fillMaxWidth(),minLines=2)
                        Button(onClick={val e=prefs.edit();e.putString("diary_${todayKey()}_proud",diaryProud).putString("diary_${todayKey()}_lesson",diaryLesson).putString("diary_${todayKey()}_feelings",diaryFeelings).putString("diary_${todayKey()}_tomorrow",diaryTomorrow).apply();diarySaved=true},modifier=Modifier.fillMaxWidth()){Text("Save diary entry")}
                        if(diarySaved) Text("Saved on this device ✓",color=Sage)
                    }
                    else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("TODAY • ${taskDone}/${tasks.size} activities",fontWeight=FontWeight.Bold); LinearProgressIndicator(progress={if(tasks.isEmpty())0f else taskDone.toFloat()/tasks.size},modifier=Modifier.fillMaxWidth(),color=Sage)
                        Text("WATER • $waterDone / $waterTarget ml",fontWeight=FontWeight.Bold); LinearProgressIndicator(progress={(waterDone.toFloat()/waterTarget.coerceAtLeast(1)).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth())
                        Text("SUPPLEMENTS • $suppDone / ${supplements.size} taken",fontWeight=FontWeight.Bold); LinearProgressIndicator(progress={if(supplements.isEmpty())0f else suppDone.toFloat()/supplements.size},modifier=Modifier.fillMaxWidth(),color=Sage)
                        Text("BOOKS • ${books.count{it.finished}} completed",fontWeight=FontWeight.Bold)
                        Text("Your check-ins are saved by date on this device. Weekly/monthly progress accumulates as you use the app.",color=Color.Gray)
                        OutlinedButton(onClick={selectedDate=todayKey()}){Text("Return to today")}
                    }
                }
            }
        }
    }
    if(showNewTask || taskDialog!=null) TaskEditor(taskDialog, onDismiss={showNewTask=false;taskDialog=null}, onSave={t->saveTasks(if(taskDialog==null)tasks+t else tasks.map{if(it.id==t.id)t else it});showNewTask=false;taskDialog=null})
    if(showNewSupplement || supplementDialog!=null) SupplementEditor(supplementDialog,onDismiss={showNewSupplement=false;supplementDialog=null},onSave={s->saveSupps(if(supplementDialog==null)supplements+s else supplements.map{if(it.id==s.id)s else it});showNewSupplement=false;supplementDialog=null})
    if(showNewBook || bookDialog!=null) BookEditor(bookDialog,onDismiss={showNewBook=false;bookDialog=null},onSave={b->saveBooks(if(bookDialog==null)books+b else books.map{if(it.id==b.id)b else it});showNewBook=false;bookDialog=null})
}

@Composable private fun CardBox(content:@Composable ColumnScope.()->Unit){ Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Pink)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp),content=content)} }
@Composable private fun RowCard(content:@Composable RowScope.()->Unit){ Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(14.dp)).padding(horizontal=8.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically,content=content) }

@Composable private fun TaskEditor(old:BloomTask?,onDismiss:()->Unit,onSave:(BloomTask)->Unit){ var title by remember{mutableStateOf(old?.title?:"")};var time by remember{mutableStateOf(old?.time?:"")};var cat by remember{mutableStateOf(old?.category?:"Personal")}; AlertDialog(onDismissRequest=onDismiss,title={Text(if(old==null)"Add activity" else "Edit activity")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("Activity name")});OutlinedTextField(time,{time=it},label={Text("Time (e.g. 6:30 AM)")});OutlinedTextField(cat,{cat=it},label={Text("Category")})}},confirmButton={TextButton(onClick={if(title.isNotBlank())onSave(BloomTask(old?.id?:newId(),title,time,cat))}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}}) }
@Composable private fun SupplementEditor(old:Supplement?,onDismiss:()->Unit,onSave:(Supplement)->Unit){var name by remember{mutableStateOf(old?.name?:"")};var dose by remember{mutableStateOf(old?.dose?:"")};var time by remember{mutableStateOf(old?.time?:"")};AlertDialog(onDismissRequest=onDismiss,title={Text(if(old==null)"Add supplement" else "Edit supplement")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text("Supplement name")});OutlinedTextField(dose,{dose=it},label={Text("Dosage")});OutlinedTextField(time,{time=it},label={Text("Usual timing (optional)")})}},confirmButton={TextButton(onClick={if(name.isNotBlank())onSave(Supplement(old?.id?:newId(),name,dose,time))}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}
@Composable private fun BookEditor(old:BloomBook?,onDismiss:()->Unit,onSave:(BloomBook)->Unit){var title by remember{mutableStateOf(old?.title?:"")};var notes by remember{mutableStateOf(old?.notes?:"")};var page by remember{mutableStateOf((old?.page?:0).toString())};var total by remember{mutableStateOf((old?.total?:0).toString())};var finished by remember{mutableStateOf(old?.finished?:false)};AlertDialog(onDismissRequest=onDismiss,title={Text(if(old==null)"Add book" else "Book details & notes")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(title,{title=it},label={Text("Book title")});OutlinedTextField(page,{page=it.filter(Char::isDigit)},label={Text("Current page")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number));OutlinedTextField(total,{total=it.filter(Char::isDigit)},label={Text("Total pages")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number));OutlinedTextField(notes,{notes=it},label={Text("Notes / important points")},minLines=3);Row(verticalAlignment=Alignment.CenterVertically){Checkbox(finished,{finished=it});Text("Completed")}}},confirmButton={TextButton(onClick={if(title.isNotBlank())onSave(BloomBook(old?.id?:newId(),title,notes,page.toIntOrNull()?:0,total.toIntOrNull()?:0,finished))}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

private fun editWaterDialog(context:Context,slot:WaterSlot,onSave:(WaterSlot)->Unit){ val time=android.widget.EditText(context).apply{setText(slot.time);hint="Time (e.g. 7:00 PM)"};val ml=android.widget.EditText(context).apply{setText(slot.ml.toString());hint="Amount in ml";inputType=2};android.app.AlertDialog.Builder(context).setTitle("Edit water reminder").setView(android.widget.LinearLayout(context).apply{orientation=1;setPadding(40,20,40,10);addView(time);addView(ml)}).setPositiveButton("Save"){_,_->onSave(slot.copy(time=time.text.toString(),ml=ml.text.toString().toIntOrNull()?:slot.ml))}.setNegativeButton("Cancel",null).show() }

private fun loadTasks(p:android.content.SharedPreferences):List<BloomTask> = decodeTasks(p.getString("tasks",null)) ?: defaultTasks()
private fun loadSupplements(p:android.content.SharedPreferences):List<Supplement> = decodeSupps(p.getString("supplements",null)) ?: listOf(Supplement("s-protein","Protein","1 serving","After workout"),Supplement("s-daily","Daily Plus","1 tablet","After breakfast"),Supplement("s-omega","Omega-3","1 capsule","After food"))
private fun loadBooks(p:android.content.SharedPreferences):List<BloomBook> = decodeBooks(p.getString("bloom_books_v2",null)) ?: emptyList()
private fun loadWater(p:android.content.SharedPreferences):List<WaterSlot> = decodeWater(p.getString("water_slots",null)) ?: defaultWater()
private fun enc(items:List<org.json.JSONObject>)=org.json.JSONArray().also{a->items.forEach { a.put(it) }}.toString()
private fun decode(raw:String?,f:(org.json.JSONObject)->Any):List<Any>?=try{if(raw==null)null else {val a=org.json.JSONArray(raw);(0 until a.length()).map{f(a.getJSONObject(it))}}}catch(_:Exception){null}
private fun encodeTasks(v:List<BloomTask>)=enc(v.map{org.json.JSONObject().put("id",it.id).put("title",it.title).put("time",it.time).put("category",it.category)})
private fun decodeTasks(s:String?)=try{if(s==null)null else org.json.JSONArray(s).let{a->(0 until a.length()).map{i->a.getJSONObject(i).let{o->BloomTask(o.getString("id"),o.getString("title"),o.optString("time"),o.optString("category"))}}}}catch(_:Exception){null}
private fun encodeSupps(v:List<Supplement>)=enc(v.map{org.json.JSONObject().put("id",it.id).put("name",it.name).put("dose",it.dose).put("time",it.time)})
private fun decodeSupps(s:String?)=try{if(s==null)null else org.json.JSONArray(s).let{a->(0 until a.length()).map{i->a.getJSONObject(i).let{o->Supplement(o.getString("id"),o.getString("name"),o.optString("dose"),o.optString("time"))}}}}catch(_:Exception){null}
private fun encodeBooks(v:List<BloomBook>)=enc(v.map{org.json.JSONObject().put("id",it.id).put("title",it.title).put("notes",it.notes).put("page",it.page).put("total",it.total).put("finished",it.finished)})
private fun decodeBooks(s:String?)=try{if(s==null)null else org.json.JSONArray(s).let{a->(0 until a.length()).map{i->a.getJSONObject(i).let{o->BloomBook(o.getString("id"),o.getString("title"),o.optString("notes"),o.optInt("page"),o.optInt("total"),o.optBoolean("finished"))}}}}catch(_:Exception){null}
private fun encodeWater(v:List<WaterSlot>)=enc(v.map{org.json.JSONObject().put("id",it.id).put("time",it.time).put("ml",it.ml)})
private fun decodeWater(s:String?)=try{if(s==null)null else org.json.JSONArray(s).let{a->(0 until a.length()).map{i->a.getJSONObject(i).let{o->WaterSlot(o.getString("id"),o.optString("time"),o.optInt("ml",200))}}}}catch(_:Exception){null}
