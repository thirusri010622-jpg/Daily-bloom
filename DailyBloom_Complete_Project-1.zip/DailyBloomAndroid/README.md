# Daily Bloom – Android project

Pastel cream, blush and sage personal planner. Package: `com.dailybloom.tracker`.

## Build an installable APK with GitHub Actions
1. Upload the contents of this folder to the root of your GitHub repository (keep the `.github/workflows/build-apk.yml` file).
2. Open **Actions → Build Daily Bloom APK → Run workflow** (or wait for the push build).
3. When the run finishes with a green check, open it and download **Daily-Bloom-APK**.
4. Extract the artifact ZIP and tap `app-debug.apk` on your Android phone to install.

The app uses local SharedPreferences on the phone. Updating an installed app with the same application ID and signing key normally preserves app data; uninstalling or clearing app data deletes it. Back up important diary entries before replacing an app.

## Included
- Editable activities and times, completion check-ins by date, custom daily activity reminders.
- Editable water reminder slots, ml amounts, daily target and completion tracking.
- Supplements add/edit/delete and Taken/Not Taken history (no supplement alarms).
- Reading list with edit/delete, notes, page progress and completion marker.
- Healing affirmations with Android text-to-speech playback and stop.
- Date-keyed diary sections: proud moments, lessons, feelings and tomorrow's intention.
- Daily progress summary and local data storage.

Reminder notifications require notification permission. Exact alarms may fall back to inexact alarms if Android does not grant exact-alarm access. For dependable background reminders, allow Daily Bloom notifications and unrestricted battery use in Android settings.
